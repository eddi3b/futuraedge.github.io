
(function(compId){var _=null,y=true,n=false,x66='break-word',x98='271px',x73='futura-pt, sans-serif',x75='About',e17='${HomeBTN_ABOUT}',e36='${HoverLeft_HOME}',b='block',e24='${TURA22}',e30='${About_Content}',x69='Text2',e31='${Letters_BTN}',e21='${RightStart}',x94='260px',x64='rgba(255,255,255,1.00)',d='display',x100='864px',i='none',x12='rgba(192,192,192,1)',x97='185px',x3='6.0.0.400',e44='${IamEMB_ForwardnessNefficiency_GrOFW}',x96='123px',lf='left',x15='rgba(53,55,52,1.00)',x65='400',e19='${StylePLACEHOLDER}',x93='305px',x87='24px',x91='432px',x89='rgba(238,0,0,1)',e56='${P2R2WEBver1-LR-07}',x79='41px',x51='auto',x92='11px',e45='${HoverRight_NUMBERS}',e20='${Forward}',x54='P2R2WEBver1-LR-07',e25='${About_BTNRESET}',tp='top',x50='287px',e41='${HoverLeft_ABOUT}',xc='rgba(0,0,0,1)',e84='${Text2Copy3}',x83='31px',x82='Text2Copy3',e34='${NumberBTN_NUMBER}',e80='${Text2Copy2}',x2='5.0.0',c='color',x5='rgba(0,0,0,0)',x55='495px',e57='${P2R2WEBver1-LR-06}',g='image',x4='both',x78='Text2Copy2',x63='Tahoma, Geneva, sans-serif',e76='${About}',x58='P2R2WEBver1-LR-063',e22='${HoverLeft_NUMBERS}',e72='${Text2}',x71='13px',e32='${HoverLeft_STYLE}',x70='28px',x67='nowrap',x='text',x86='Text2Copy4',x95='Poster',x60='P2R2WEBver1-LR-073',m='rect',x48='0px',h='height',e39='${HoverRight_ABOUT}',x62='pointer',e46='${HoverRight_LETTERS}',e33='${AboutBTN_HOME}',e37='${HoverRight_STYLE}',x1='6.0.0',p='px',o='opacity',e61='${P2R2WEBver1-LR-073}',e26='${HoverLeft_LETTERS}',e88='${Text2Copy4}',x53='P2R2WEBver1-LR-06',e59='${P2R2WEBver1-LR-063}',e27='${LStart}',e16='${AboutBTN_ABOUT}',x52='visible',e38='${HoverRight_HOME}',l='normal',e23='${TURA2}',e42='${NumbersPLACEHOLDER}',e18='${Number_BTN}',e35='${LettersPLACEHOLDER}',e29='${HomeBTN}',e40='${HitRegion}',x47='643px',e43='${OpeningBrackets}',x49='148px',e28='${Style_BTN}',w='width';var g6='P2R2WEBver1-LR-06.png',g99='Poster.png',g9='Letters.png',g7='P2R2WEBver1-LR-07.png',g8='Numbers.png',g11='Forward.png',g14='TURA2.png',g13='IamEMB_ForwardnessNefficiency_GrOFW.mp4',g10='Style.png';var s81="<p style=\"margin: 0px;\">Letters</p>",s90="<p style=\"margin: 0px;\">​<span style=\"color: rgb(255, 255, 255); font-family: futura-pt, sans-serif;\">Futura defined many icons of media from magazines to fashion brands. It has overcome a lot before it became one of the most widely used fonts of our time, one of the biggest obstacles was the Nazis. Having originated from Germany, Paul Renner was the designer of Futura and he came to it from book design where it was key to communicate clearly. It was the 1920’s and the Bauhaus School of Design was becoming popular. Although not part of the school, but like Bauhaus designers, he wanted function and beauty. In the 1920’s when people thought of German typography, people thought of fraktur style typography, and Renner thought it didn’t work. He said, “…fraktur was like leaderhosen.. it was outdated and quaint.”&nbsp;</span></p><p style=\"margin: 0px;\"><span style=\"color: rgb(255, 255, 255); font-family: futura-pt, sans-serif;\">​</span></p><p style=\"margin: 0px;\"><span style=\"color: rgb(255, 255, 255); font-family: futura-pt, sans-serif;\">With a couple of years of development, Futura went on the market in 1927. It was sold as “the typeface of our time.” The typeface is modern and way ahead of its time. Some early adaptations were extreme however, there were heavy geometric figures like in the original lowercase “g” or “a” for instance. The look was liberal and in the air with other typefaces, like Johnston and Akzidenz Grotesk, but Renner thought Futura was unique. He states that Futura is an “eminently German typeface” and the type foundry, Bauer, sold it as “the type of the future.” Futura gained broad international distribution, showing up on charts or being overlaid on pictures.</span></p><p style=\"margin: 0px;\"><span style=\"color: rgb(255, 255, 255); font-family: futura-pt, sans-serif;\">​</span></p><p style=\"margin: 0px;\"><span style=\"color: rgb(255, 255, 255); font-family: futura-pt, sans-serif;\">It became a symbol of the future – and for the Nazis, it was a problem. Fraktur – the Gothic style Renner rejected was the font of the Nazis used in the 1930’s. The Nazis started neglecting modern fonts in favor of ornate decorative styles. With this, Renner became an outcast after writing his famous anti-Nazi essay. He was arrested, and along with sans-serif type, was casted out of Germany. Interestingly, Renner was allowed back to Germany, and the Nazis occasionally utilized Futura. In addition, the Nazis also decided the Fraktur font they commonly used was a “Jewish” style font, so they banned it.&nbsp;</span></p><p style=\"margin: 0px;\"><span style=\"color: rgb(255, 255, 255); font-family: futura-pt, sans-serif;\">​</span></p><p style=\"margin: 0px;\"><span style=\"color: rgb(255, 255, 255); font-family: futura-pt, sans-serif;\">The Nazis came around to Renner’s idea, that the German typeface of the future had to be more readable. By that time, Futura ended up being established as an international typeface, and perhaps is what saved the font from disappearing from history. During World War II, a lot of different, modern-looking sans-serif fonts were kicking around NASA’s predecessor, NACA, and the rest of the American military.&nbsp;</span></p><p style=\"margin: 0px;\"><span style=\"color: rgb(255, 255, 255); font-family: futura-pt, sans-serif;\">​</span></p><p style=\"margin: 0px;\"><span style=\"color: rgb(255, 255, 255); font-family: futura-pt, sans-serif;\">At the time, people chose fonts based on the availability of physical pieces of type. Futura was available and made it an obvious choice since the typeface was very clear and concise. When NASA needed a plaque for Apollo 11, they chosen one font; they pulled form a typeface that would become beloved by Stanley Kubrick and Wes Anderson. They used the uniquely German design that through a talented and idealistic creator, traveled beyond the Nazis, beyond the 1940s, beyond Germany, and beyond Earth.</span></p><p style=\"margin: 0px;\"><span style=\"color: rgb(255, 255, 255); font-family: futura-pt, sans-serif;\">​</span></p>",s68="<p style=\"margin: 0px;\">​Hom<span style=\"font-family: futura-pt, sans-serif;\">​</span>e</p>",s85="<p style=\"margin: 0px;\">Style</p>",s77="<p style=\"margin: 0px;\">Numbers</p>",s74="<p style=\"margin: 0px;\">About</p>";var im='images/',aud='media/',vid='media/',js='js/',fonts={'futura-pt, sans-serif':'<script>  (function(d) {    var config = {      kitId: \'tce4gpu\',      scriptTimeout: 3000,      async: true    },    h=d.documentElement,t=setTimeout(function(){h.className=h.className.replace(/ wf-loading /g,\"\")+\" wf-inactive\";},config.scriptTimeout),tk=d.createElement(\"script\"),f=false,s=d.getElementsByTagName(\"script\")[0],a;h.className+=\" wf-loading\";tk.src=\'https://use.typekit.net/\'+config.kitId+\'.js\';tk.async=true;tk.onload=tk.onreadystatechange=function(){a=this.readyState;if(f||a&&a!=\"complete\"&&a!=\"loaded\")return;f=true;clearTimeout(t);try{Typekit.load(config)}catch(e){}};s.parentNode.insertBefore(tk,s)  })(document);</script>'},opts={'gAudioPreloadPreference':'auto','gVideoPreloadPreference':'auto'},resources=[],scripts=[],symbols={"stage":{v:x1,mv:x2,b:x3,stf:w,cg:x4,rI:n,cn:{dom:[{id:'RightStart',v:b,t:g,r:['668px','12px','148px','287px','auto','auto'],f:[x5,im+g6,'0px','0px']},{id:'LStart',v:b,t:g,r:['532px','12px','30px','59px','auto','auto'],f:[x5,im+g7,'0px','0px']},{id:'OpeningBrackets',symbolName:'OpeningBrackets',v:i,t:m,r:['363px','42','495','287','auto','auto'],cu:'default'},{id:'NumbersPLACEHOLDER',v:i,t:g,r:['-2px','-221px','1229px','796px','auto','auto'],cl:'rect(220px 1229px 591px 0px)',o:'0',f:[x5,im+g8,'0px','0px']},{id:'LettersPLACEHOLDER',t:g,r:['0px','-220px','1228px','796px','auto','auto'],cl:'rect(220px 1228px 591px 0px)',f:[x5,im+g9,'0px','0px']},{id:'StylePLACEHOLDER',t:g,r:['-2px','-220px','1228px','796px','auto','auto'],cl:'rect(220px 1228px 591px 0px)',f:[x5,im+g10,'0px','0px']},{id:'HoverLeft_HOME',symbolName:'HoverLeft',v:i,t:m,r:['71px','42px','148','287','auto','auto'],cu:'pointer'},{id:'HoverRight_HOME',symbolName:'HoverRight',v:i,t:m,r:['1006px','42px','148','287','auto','auto'],cu:'pointer'},{id:'HoverLeft_ABOUT',symbolName:'HoverLeft',v:i,t:m,r:['71px','42px','148','287','auto','auto'],cu:'pointer'},{id:'HoverRight_ABOUT',symbolName:'HoverRight',v:i,t:m,r:['1006px','42px','148','287','auto','auto'],cu:'pointer'},{id:'HoverLeft_NUMBERS',symbolName:'HoverLeft',v:i,t:m,r:['71px','42px','148','287','auto','auto'],cu:'pointer'},{id:'HoverRight_NUMBERS',symbolName:'HoverRight',v:i,t:m,r:['1006px','42px','148','287','auto','auto'],cu:'pointer'},{id:'HoverLeft_LETTERS',symbolName:'HoverLeft',v:i,t:m,r:['71px','42px','148','287','auto','auto'],cu:'pointer'},{id:'HoverRight_LETTERS',symbolName:'HoverRight',v:i,t:m,r:['1006px','42px','148','287','auto','auto'],cu:'pointer'},{id:'HoverLeft_STYLE',symbolName:'HoverLeft',v:i,t:m,r:['71px','42px','148','287','auto','auto'],cu:'pointer'},{id:'HoverRight_STYLE',symbolName:'HoverRight',v:i,t:m,r:['1006px','42px','148','287','auto','auto'],cu:'pointer'},{id:'Forward',v:b,t:g,r:['498px','163px','231px','44px','auto','auto'],o:'1',f:[x5,im+g11,'0px','0px']},{id:'HitRegion',v:b,t:m,r:['471px','162px','278px','50px','auto','auto'],overflow:'visible',cu:'pointer',o:'0',f:[x12],s:[0,xc,i]},{id:'IamEMB_ForwardnessNefficiency_GrOFW',v:i,t:'video',tag:'video',r:['160px','71px','901px','230px','auto','auto'],sr:[vid+g13],pr:'auto'},{id:'HomeBTN',symbolName:'HomeBTN',v:i,t:m,r:['518px','76px','28','13','auto','auto'],cu:'pointer',o:'0',tf:[[],[],[],['0.85714']]},{id:'HomeBTN_ABOUT',symbolName:'HomeBTN',v:i,t:m,r:['518px','76px','28','13','auto','auto'],cu:'pointer',o:'0',tf:[[],[],[],['0.85714']]},{id:'AboutBTN_HOME',symbolName:'About_BTN',v:i,t:m,r:['554px','76px','28','13','auto','auto'],cu:'pointer',o:'0'},{id:'AboutBTN_ABOUT',symbolName:'About_BTN',v:i,t:m,r:['554px','76px','28','13','auto','auto'],cu:'pointer',o:'0'},{id:'About_BTNRESET',symbolName:'About_BTN',v:i,t:m,r:['554px','76px','28','13','auto','auto'],cu:'pointer',o:'0'},{id:'Number_BTN',symbolName:'Number_BTN',v:i,t:m,r:['593px','76px','41','13','auto','auto'],cu:'pointer',o:'0'},{id:'NumberBTN_NUMBER',symbolName:'Number_BTN',v:i,t:m,r:['593px','76px','41','13','auto','auto'],cu:'pointer',o:'0'},{id:'Letters_BTN',symbolName:'Letters_BTN',v:i,t:m,r:['645px','76px','31','13','auto','auto'],cu:'pointer',o:'0'},{id:'Style_BTN',symbolName:'Style_BTN',v:i,t:m,r:['686px','76px','24','13','auto','auto'],cu:'pointer',o:'0'},{id:'TURA2',v:i,t:g,r:['395px','-40px','402px','402px','auto','auto'],cl:'rect(138px 359px 319px 45px)',o:'0',f:[x5,im+g14,'0px','0px']},{id:'TURA22',v:i,t:g,r:['579px','-1px','70px','70px','auto','auto'],cl:'rect(23px 70px 58px 0px)',cu:'pointer',o:'0',f:[x5,im+g14,'0px','0px'],tf:[[],[],[],['1.49523','1.49523']]},{id:'About_Content',symbolName:'About_Content',v:b,t:m,r:['182','371px','864','271','auto','auto']}],style:{'${Stage}':{isStage:true,r:['null','null','1225px','371px','auto','auto'],zr:['0px','','',''],overflow:'hidden',f:[x15]}}},tt:{d:63500,a:y,l:{"Wait":0,"O":1001,"GO_HOME":12250,"HOME":12250,"HOME_END":12750,"About":14000,"About_End":18877,"Numbers":19000,"Number_End":23877,"Letters":24000,"Style":29000,"About_Reset":60000,"Home_Reset":63000},data:[["eid330",lf,14000,0,"linear",e16,'554px','554px'],["eid331",lf,19000,0,"linear",e16,'554px','554px'],["eid374",lf,60000,0,"linear",e16,'554px','554px'],["eid332",lf,63000,0,"linear",e16,'554px','554px'],["eid314",tp,14000,500,"swing",e17,'26px','76px'],["eid315",tp,19000,500,"swing",e17,'76px','26px'],["eid392",tp,60000,500,"swing",e17,'26px','76px'],["eid316",tp,63000,500,"swing",e17,'76px','26px'],["eid194",lf,14000,0,"linear",e18,'593px','593px'],["eid271",lf,19000,0,"linear",e18,'593px','593px'],["eid371",lf,60000,0,"linear",e18,'593px','593px'],["eid291",lf,63000,0,"linear",e18,'593px','593px'],["eid453",lf,5750,0,"swing",e19,'-2px','-2px'],["eid474",o,1001,798,"linear",e20,'1','0'],["eid235",h,14000,500,"swing",e21,'287px','59px'],["eid258",h,19000,500,"swing",e21,'59px','287px'],["eid401",h,60000,500,"swing",e21,'287px','59px'],["eid306",h,63000,500,"swing",e21,'59px','287px'],["eid152",d,0,0,"linear",e22,i,i],["eid166",d,19000,0,"linear",e22,i,i],["eid262",d,19500,0,"swing",e22,i,b],["eid168",d,24000,0,"linear",e22,b,i],["eid102",o,12250,500,"swing",e23,'0','1'],["eid208",o,14000,500,"swing",e23,'1','0'],["eid324",o,63000,500,"swing",e23,'0','1'],["eid232",o,14000,500,"swing",e24,'0','1'],["eid265",o,19000,500,"swing",e24,'1','0'],["eid385",o,60000,500,"swing",e24,'0','1'],["eid286",o,63000,500,"swing",e24,'1','0'],["eid427",d,0,0,"swing",e25,i,i],["eid416",d,19000,0,"swing",e25,i,b],["eid417",d,60000,0,"swing",e25,b,i],["eid310",o,11375,494,"linear",e17,'0','1'],["eid150",d,0,0,"linear",e26,i,i],["eid170",d,24000,0,"linear",e26,i,b],["eid172",d,29000,0,"linear",e26,b,i],["eid187",lf,0,0,"linear",e27,'363px','363px'],["eid237",lf,14000,500,"swing",e27,'71px','532px'],["eid251",lf,19000,500,"swing",e27,'532px','71px'],["eid397",lf,60000,500,"swing",e27,'71px','532px'],["eid301",lf,63000,500,"swing",e27,'532px','71px'],["eid80",d,11375,0,"linear",e28,i,b],["eid333",tp,14000,500,"swing",e16,'26px','76px'],["eid334",tp,19000,500,"swing",e16,'76px','26px'],["eid390",tp,60000,500,"swing",e16,'26px','76px'],["eid335",tp,63000,500,"swing",e16,'76px','26px'],["eid239",h,14000,500,"swing",e27,'287px','59px'],["eid254",h,19000,500,"swing",e27,'59px','287px'],["eid396",h,60000,500,"swing",e27,'287px','59px'],["eid300",h,63000,500,"swing",e27,'59px','287px'],["eid236",w,14000,500,"swing",e21,'148px','30px'],["eid257",w,19000,500,"swing",e21,'30px','148px'],["eid403",w,60000,500,"swing",e21,'148px','30px'],["eid308",w,63000,500,"swing",e21,'30px','148px'],["eid78",o,11375,494,"linear",e29,'0','1'],["eid408",d,14000,0,"swing",e30,b,i],["eid409",d,14124,0,"swing",e30,i,b],["eid410",d,19376,0,"swing",e30,b,i],["eid412",d,60000,0,"swing",e30,i,b],["eid413",d,60500,0,"swing",e30,b,i],["eid81",d,11375,0,"linear",e31,i,b],["eid148",d,0,0,"linear",e32,i,i],["eid174",d,29000,0,"linear",e32,i,b],["eid175",d,34000,0,"linear",e32,b,i],["eid195",lf,14000,0,"linear",e33,'554px','554px'],["eid273",lf,19000,0,"linear",e33,'554px','554px'],["eid377",lf,60000,0,"linear",e33,'554px','554px'],["eid294",lf,63000,0,"linear",e33,'554px','554px'],["eid418",o,11375,494,"linear",e25,'0.000000','1'],["eid188",lf,0,0,"linear",e21,'710px','710px'],["eid233",lf,14000,500,"swing",e21,'1006px','668px'],["eid255",lf,19000,500,"swing",e21,'668px','1006px'],["eid402",lf,60000,500,"swing",e21,'1006px','668px'],["eid307",lf,63000,500,"swing",e21,'668px','1006px'],["eid76",o,11375,494,"linear",e31,'0.000000','1'],["eid206",tp,14000,500,"swing",e29,'26px','76px'],["eid282",tp,19000,500,"swing",e29,'76px','26px'],["eid456",tp,29000,0,"swing",e29,'26px','26px'],["eid393",tp,60000,500,"swing",e29,'26px','76px'],["eid296",tp,63000,500,"swing",e29,'76px','26px'],["eid74",o,11375,494,"linear",e28,'0.000000','1'],["eid311",lf,14000,0,"linear",e17,'518px','518px'],["eid312",lf,19000,0,"linear",e17,'518px','518px'],["eid380",lf,60000,0,"linear",e17,'518px','518px'],["eid313",lf,63000,0,"linear",e17,'518px','518px'],["eid202",tp,14000,500,"swing",e28,'26px','76px'],["eid283",tp,19000,500,"swing",e28,'76px','26px'],["eid386",tp,60000,500,"swing",e28,'26px','76px'],["eid288",tp,63000,500,"swing",e28,'76px','26px'],["eid196",lf,14000,0,"linear",e29,'518px','518px'],["eid275",lf,19000,0,"linear",e29,'518px','518px'],["eid383",lf,60000,0,"linear",e29,'518px','518px'],["eid295",lf,63000,0,"linear",e29,'518px','518px'],["eid204",tp,14000,500,"swing",e31,'26px','76px'],["eid279",tp,19000,500,"swing",e31,'76px','26px'],["eid387",tp,60000,500,"swing",e31,'26px','76px'],["eid290",tp,63000,500,"swing",e31,'76px','26px'],["eid352",lf,14000,0,"linear",e34,'593px','593px'],["eid353",lf,19000,0,"linear",e34,'593px','593px'],["eid368",lf,60000,0,"linear",e34,'593px','593px'],["eid354",lf,63000,0,"linear",e34,'593px','593px'],["eid435",d,24000,0,"swing",e35,b,b],["eid436",d,24500,0,"swing",e35,b,b],["eid440",d,29000,0,"swing",e35,b,b],["eid441",d,29500,0,"swing",e35,b,i],["eid205",tp,14000,500,"swing",e33,'26px','76px'],["eid281",tp,19000,500,"swing",e33,'76px','26px'],["eid391",tp,60000,500,"swing",e33,'26px','76px'],["eid293",tp,63000,500,"swing",e33,'76px','26px'],["eid405",tp,14124,376,"swing",e30,'371px','100px'],["eid407",tp,19000,376,"swing",e30,'100px','371px'],["eid411",tp,60000,376,"swing",e30,'371px','100px'],["eid193",lf,14000,0,"linear",e31,'645px','645px'],["eid269",lf,19000,0,"linear",e31,'645px','645px'],["eid366",lf,60000,0,"linear",e31,'645px','645px'],["eid289",lf,63000,0,"linear",e31,'645px','645px'],["eid38",d,0,0,"easeInOutQuad",e36,i,i],["eid43",d,1799,0,"linear",e36,i,b],["eid159",d,14000,0,"linear",e36,b,i],["eid238",tp,14000,500,"swing",e27,'42px','12px'],["eid252",tp,19000,500,"swing",e27,'12px','42px'],["eid394",tp,60000,500,"swing",e27,'42px','12px'],["eid297",tp,63000,500,"swing",e27,'12px','42px'],["eid149",d,0,0,"linear",e37,i,i],["eid173",d,29000,0,"linear",e37,i,b],["eid176",d,34000,0,"linear",e37,b,i],["eid234",tp,14000,500,"swing",e21,'42px','12px'],["eid256",tp,19000,500,"swing",e21,'12px','42px'],["eid399",tp,60000,500,"swing",e21,'42px','12px'],["eid303",tp,63000,500,"swing",e21,'12px','42px'],["eid39",d,0,0,"easeInOutQuad",e38,i,i],["eid42",d,1799,0,"linear",e38,i,b],["eid160",d,14000,0,"linear",e38,b,i],["eid475",d,1799,0,"linear",e20,b,i],["eid155",d,0,0,"linear",e39,i,i],["eid162",d,14000,0,"linear",e39,i,i],["eid97",d,12250,0,"linear",e23,i,b],["eid209",d,14500,0,"swing",e23,b,i],["eid325",d,63000,0,"swing",e23,i,b],["eid37",d,1001,0,"easeInOutQuad",e40,b,i],["eid449",d,29000,0,"swing",e19,b,b],["eid450",d,29500,0,"swing",e19,b,b],["eid452",d,33877,0,"swing",e19,b,i],["eid29",d,1001,0,"easeInOutQuad",e27,b,i],["eid181",d,14000,0,"linear",e27,i,b],["eid242",d,19000,0,"linear",e27,b,b],["eid259",d,19500,0,"swing",e27,b,i],["eid395",d,60000,0,"linear",e27,i,b],["eid298",d,63000,0,"linear",e27,b,b],["eid299",d,63500,0,"swing",e27,b,i],["eid83",d,11375,0,"linear",e33,i,b],["eid336",d,14000,0,"swing",e33,b,i],["eid376",d,60000,0,"swing",e33,b,b],["eid154",d,0,0,"linear",e41,i,i],["eid161",d,14000,0,"linear",e41,i,i],["eid75",o,11375,494,"linear",e18,'0.000000','1'],["eid358",d,0,0,"swing",e34,i,i],["eid357",d,19000,0,"swing",e34,i,b],["eid369",d,60000,0,"swing",e34,b,b],["eid359",d,0,0,"swing",e16,i,i],["eid337",d,14000,0,"swing",e16,i,b],["eid338",d,19000,0,"swing",e16,b,i],["eid375",d,60000,0,"swing",e16,i,i],["eid423",tp,14000,500,"swing",e25,'26px','76px'],["eid424",tp,19000,500,"swing",e25,'76px','26px'],["eid425",tp,60000,500,"swing",e25,'26px','76px'],["eid426",tp,63000,500,"swing",e25,'76px','26px'],["eid430",d,19376,0,"swing",e42,i,b],["eid431",d,24000,0,"swing",e42,b,b],["eid434",d,24500,0,"swing",e42,b,i],["eid30",d,1001,0,"easeInOutQuad",e21,b,i],["eid182",d,14000,0,"linear",e21,i,b],["eid247",d,19000,0,"linear",e21,b,b],["eid260",d,19500,0,"swing",e21,b,i],["eid400",d,60000,0,"linear",e21,i,b],["eid304",d,63000,0,"linear",e21,b,b],["eid305",d,63500,0,"swing",e21,b,i],["eid22",d,0,0,"easeInOutQuad",e43,i,i],["eid23",d,1001,0,"easeInOutQuad",e43,i,b],["eid139",d,1799,0,"linear",e43,b,i],["eid327",d,14000,0,"swing",e17,i,b],["eid318",d,19000,0,"swing",e17,b,i],["eid379",d,60000,0,"swing",e17,i,i],["eid320",d,63000,0,"swing",e17,i,b],["eid348",tp,14000,500,"swing",e34,'26px','76px'],["eid349",tp,19000,500,"swing",e34,'76px','26px'],["eid388",tp,60000,500,"swing",e34,'26px','76px'],["eid350",tp,63000,500,"swing",e34,'76px','26px'],["eid82",d,11375,0,"linear",e18,i,b],["eid356",d,19000,0,"swing",e18,b,i],["eid372",d,60000,0,"swing",e18,i,i],["eid49",d,1799,0,"swing",e44,i,b],["eid92",d,12000,0,"linear",e44,b,i],["eid228",d,14000,0,"swing",e24,i,b],["eid263",d,19000,0,"swing",e24,b,b],["eid266",d,19500,0,"swing",e24,b,i],["eid360",d,60000,0,"swing",e24,i,b],["eid361",d,60500,0,"swing",e24,b,i],["eid284",d,63000,0,"swing",e24,i,b],["eid285",d,63500,0,"swing",e24,b,i],["eid203",tp,14000,500,"swing",e18,'26px','76px'],["eid280",tp,19000,500,"swing",e18,'76px','26px'],["eid389",tp,60000,500,"swing",e18,'26px','76px'],["eid292",tp,63000,500,"swing",e18,'76px','26px'],["eid240",w,14000,500,"swing",e27,'148px','30px'],["eid253",w,19000,500,"swing",e27,'30px','148px'],["eid398",w,60000,500,"swing",e27,'148px','30px'],["eid302",w,63000,500,"swing",e27,'30px','148px'],["eid192",lf,14000,0,"linear",e28,'686px','686px'],["eid267",lf,19000,0,"linear",e28,'686px','686px'],["eid363",lf,60000,0,"linear",e28,'686px','686px'],["eid287",lf,63000,0,"linear",e28,'686px','686px'],["eid451",o,29000,500,"swing",e19,'0','1'],["eid428",o,19376,500,"swing",e42,'0','1'],["eid433",o,24000,500,"swing",e42,'1','0'],["eid419",lf,14000,0,"linear",e25,'554px','554px'],["eid420",lf,19000,0,"linear",e25,'554px','554px'],["eid421",lf,60000,0,"linear",e25,'554px','554px'],["eid422",lf,63000,0,"linear",e25,'554px','554px'],["eid351",o,11375,494,"linear",e34,'0.000000','1'],["eid153",d,0,0,"linear",e45,i,i],["eid165",d,19000,0,"linear",e45,i,i],["eid261",d,19500,0,"swing",e45,i,b],["eid167",d,24000,0,"linear",e45,b,i],["eid329",o,11375,494,"linear",e16,'0.000000','1'],["eid79",d,11375,0,"linear",e29,i,b],["eid317",d,14000,0,"swing",e29,b,i],["eid319",d,19000,0,"swing",e29,i,b],["eid382",d,60000,0,"swing",e29,b,b],["eid321",d,63000,0,"swing",e29,b,i],["eid151",d,0,0,"linear",e46,i,i],["eid169",d,24000,0,"linear",e46,i,b],["eid171",d,29000,0,"linear",e46,b,i],["eid438",o,24000,500,"swing",e35,'0','1'],["eid442",o,29000,500,"swing",e35,'1','0'],["eid77",o,11375,494,"linear",e33,'0.000000','1'],["eid11","tr",1001,function(e,d){this.eSA(e,d);},['play','${OpeningBrackets}',[]]],["eid50","tr",1800,function(e,d){this.eMA(e,d);},['play','${IamEMB_ForwardnessNefficiency_GrOFW}',[]]]]}},"OpeningBrackets":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{r:[x47,x48,x49,x50,x51,x51],overflow:x52,id:x53,t:g,v:b,f:[x5,im+g6,x48,x48]},{r:[x48,x48,x49,x50,x51,x51],overflow:x52,id:x54,t:g,v:b,f:[x5,im+g7,x48,x48]}],style:{'${symbolSelector}':{r:[_,_,x55,x50]}}},tt:{d:799,a:n,data:[["eid7",d,0,0,"easeInOutQuad",e56,b,b],["eid9",d,799,0,"easeInOutQuad",e56,b,i],["eid6",d,0,0,"easeInOutQuad",e57,b,b],["eid8",d,799,0,"easeInOutQuad",e57,b,i],["eid2",lf,0,798,"easeInOutQuad",e56,'0px','-292px'],["eid1",lf,0,798,"easeInOutQuad",e57,'347px','643px']]}},"HoverRight":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{r:[x48,x48,x49,x50,x51,x51],id:x58,t:g,f:[x5,im+g6,x48,x48]}],style:{'${symbolSelector}':{r:[_,_,x49,x50]}}},tt:{d:300,a:n,data:[["eid44",lf,0,300,"swing",e59,'0px','50px']]}},"HoverLeft":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{t:g,id:x60,r:[x48,x48,x49,x50,x51,x51],f:[x5,im+g7,x48,x48]}],style:{'${symbolSelector}':{r:[_,_,x49,x50]}}},tt:{d:300,a:n,data:[["eid45",lf,0,300,"swing",e61,'0px','-50px']]}},"HomeBTN":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{t:x,align:lf,ts:['','','','',i],cu:x62,n:[x63,[10,p],x64,x65,i,l,x66,x67],text:s68,id:x69,r:[x48,x48,x51,x51,x51,x51]}],style:{'${symbolSelector}':{r:[_,_,x70,x71]}}},tt:{d:3000,a:n,l:{"UP":0,"OVER":1000,"Down":2011,"ACTIVE":3000},data:[["eid60",c,0,0,"swing",e72,'rgba(255,255,255,1.00)','rgba(255,255,255,1.00)'],["eid57",c,989,0,"swing",e72,'rgba(255,255,255,1.00)','rgba(0,173,238,1.00)'],["eid63",c,2000,0,"swing",e72,'rgba(0,173,238,1.00)','rgba(0,173,238,1.00)'],["eid59",c,3000,0,"swing",e72,'rgba(0,173,238,1.00)','rgba(238,0,0,1.00)']]}},"About_BTN":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{t:x,align:lf,ts:['','','','',i],cu:x62,n:[x73,[10,p],x64,x65,i,l,x66,x67],text:s74,id:x75,r:[x48,x48,x51,x51,x51,x51]}],style:{'${symbolSelector}':{r:[_,_,x70,x71]}}},tt:{d:3000,a:n,l:{"UP":0,"OVER":1000,"Down":2011,"ACTIVE":3000},data:[["eid457",c,0,0,"swing",e76,'rgba(255,255,255,1.00)','rgba(255,255,255,1.00)'],["eid458",c,989,0,"swing",e76,'rgba(255,255,255,1.00)','rgba(0,173,238,1.00)'],["eid459",c,2000,0,"swing",e76,'rgba(0,173,238,1.00)','rgba(0,173,238,1.00)'],["eid460",c,3000,0,"swing",e76,'rgba(0,173,238,1.00)','rgba(238,0,0,1.00)']]}},"Number_BTN":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{t:x,align:lf,ts:['','','','',i],cu:x62,n:[x73,[10,p],x64,x65,i,l,x66,x67],text:s77,id:x78,r:[x48,x48,x51,x51,x51,x51]}],style:{'${symbolSelector}':{r:[_,_,x79,x71]}}},tt:{d:3000,a:n,l:{"UP":0,"OVER":1000,"Down":2011,"ACTIVE":3000},data:[["eid461",c,0,0,"swing",e80,'rgba(255,255,255,1.00)','rgba(255,255,255,1.00)'],["eid462",c,989,0,"swing",e80,'rgba(255,255,255,1.00)','rgba(0,173,238,1.00)'],["eid463",c,2000,0,"swing",e80,'rgba(0,173,238,1.00)','rgba(0,173,238,1.00)'],["eid464",c,3000,0,"swing",e80,'rgba(0,173,238,1.00)','rgba(238,0,0,1.00)']]}},"Letters_BTN":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{t:x,align:lf,ts:['','','','',i],cu:x62,n:[x73,[10,p],x64,x65,i,l,x66,x67],text:s81,id:x82,r:[x48,x48,x51,x51,x51,x51]}],style:{'${symbolSelector}':{r:[_,_,x83,x71]}}},tt:{d:3000,a:n,l:{"UP":0,"OVER":1000,"Down":2011,"ACTIVE":3000},data:[["eid465",c,0,0,"swing",e84,'rgba(255,255,255,1.00)','rgba(255,255,255,1.00)'],["eid466",c,989,0,"swing",e84,'rgba(255,255,255,1.00)','rgba(0,173,238,1.00)'],["eid467",c,2000,0,"swing",e84,'rgba(0,173,238,1.00)','rgba(0,173,238,1.00)'],["eid468",c,3000,0,"swing",e84,'rgba(0,173,238,1.00)','rgba(238,0,0,1.00)']]}},"Style_BTN":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{t:x,align:lf,ts:['','','','',i],cu:x62,n:[x73,[10,p],x64,x65,i,l,x66,x67],text:s85,id:x86,r:[x48,x48,x51,x51,x51,x51]}],style:{'${symbolSelector}':{r:[_,_,x87,x71]}}},tt:{d:3000,a:n,l:{"UP":0,"OVER":1000,"Down":2011,"ACTIVE":3000},data:[["eid469",c,0,0,"swing",e88,'rgba(255,255,255,1.00)','rgba(255,255,255,1.00)'],["eid470",c,989,0,"swing",e88,'rgba(255,255,255,1.00)','rgba(0,173,238,1.00)'],["eid471",c,2000,0,"swing",e88,'rgba(0,173,238,1.00)','rgba(0,173,238,1.00)'],["eid472",c,3000,0,"swing",e88,'rgba(0,173,238,1.00)','rgba(238,0,0,1.00)']]}},"About_Content":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{t:x,align:lf,ts:['','','','',i],n:[x63,[10,p],x89,x65,i,l,x66,l],overflow:x51,text:s90,r:[x91,x92,x93,x94,x51,x51],id:x69},{t:g,id:x95,r:[x96,x48,x97,x98,x51,x51],f:[x5,im+g99,x48,x48]}],style:{'${symbolSelector}':{overflow:x52,r:[_,_,x100,x98]}}},tt:{d:0,a:n,data:[]}}};AdobeEdge.registerCompositionDefn(compId,symbols,fonts,scripts,resources,opts);})("EDGE-179474352");
(function($,Edge,compId){var Composition=Edge.Composition,Symbol=Edge.Symbol;Edge.registerEventBinding(compId,function($){
//Edge symbol: 'stage'
(function(symbolName){Symbol.bindElementAction(compId,symbolName,"${HitRegion}","click",function(sym,e){sym.play("O");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",0,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${HomeBTN}","click",function(sym,e){sym.play("GO_HOME");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",11869,function(sym,e){sym.stop("HOME_END");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",12750,function(sym,e){sym.stop("HOME_END");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${HoverLeft_ABOUT}","click",function(sym,e){sym.play("GO_HOME");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${HoverRight_ABOUT}","click",function(sym,e){sym.play("Numbers");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${HoverLeft_NUMBERS}","click",function(sym,e){sym.play("About_Reset");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${HoverRight_NUMBERS}","click",function(sym,e){sym.play("Letters");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${HoverRight_HOME}","click",function(sym,e){sym.play("About");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${HoverLeft_LETTERS}","click",function(sym,e){sym.play("Numbers_End");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${HoverRight_LETTERS}","click",function(sym,e){sym.play("Style");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${HoverLeft_STYLE}","click",function(sym,e){sym.play("Letters");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",18877,function(sym,e){stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",23877,function(sym,e){stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",28877,function(sym,e){stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",33877,function(sym,e){stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",63500,function(sym,e){sym.stop("HOME_END");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${HomeBTN_ABOUT}","click",function(sym,e){sym.play("Home_Reset");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${AboutBTN_HOME}","click",function(sym,e){sym.play("About");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${AboutBTN_ABOUT}","click",function(sym,e){sym.stop("About_End");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${TURA22}","click",function(sym,e){sym.play("Home_Reset");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${Number_BTN}","click",function(sym,e){sym.play("Numbers");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${NumberBTN_NUMBER}","click",function(sym,e){sym.play("Number_End");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",60500,function(sym,e){sym.stop("About_End");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${About_BTNRESET}","click",function(sym,e){sym.play("About_Reset");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${Letters_BTN}","click",function(sym,e){sym.play("Letters");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${Style_BTN}","click",function(sym,e){sym.play("Style");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"document","compositionReady",function(sym,e){$("body").css("background-color","#353734");});
//Edge binding end
})("stage");
//Edge symbol end:'stage'

//=========================================================

//Edge symbol: 'OpeningBrackets'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",799,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindTimelineAction(compId,symbolName,"Default Timeline","stop",function(sym,e){});
//Edge binding end
})("OpeningBrackets");
//Edge symbol end:'OpeningBrackets'

//=========================================================

//Edge symbol: 'HoverRight'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",300,function(sym,e){stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",0,function(sym,e){stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",300,function(sym,e){stop();});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${P2R2WEBver1-LR-063}","mouseover",function(sym,e){sym.play();});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${P2R2WEBver1-LR-063}","mouseout",function(sym,e){sym.playReverse();});
//Edge binding end
})("HoverRight");
//Edge symbol end:'HoverRight'

//=========================================================

//Edge symbol: 'HoverLeft'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",300,function(sym,e){stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",0,function(sym,e){stop();});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${P2R2WEBver1-LR-073}","mouseover",function(sym,e){sym.play();});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${P2R2WEBver1-LR-073}","mouseout",function(sym,e){sym.playReverse();});
//Edge binding end
})("HoverLeft");
//Edge symbol end:'HoverLeft'

//=========================================================

//Edge symbol: 'HomeBTN'
(function(symbolName){Symbol.bindElementAction(compId,symbolName,"${Text2}","mouseover",function(sym,e){sym.stop("OVER");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${Text2}","mouseout",function(sym,e){sym.stop("UP");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",0,function(sym,e){stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",989,function(sym,e){stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",3000,function(sym,e){stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",2000,function(sym,e){stop();});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${Text2}","mousedown",function(sym,e){sym.stop("Down");});
//Edge binding end
})("HomeBTN");
//Edge symbol end:'HomeBTN'

//=========================================================

//Edge symbol: 'About_BTN'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",0,function(sym,e){stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",989,function(sym,e){stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",2000,function(sym,e){stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",3000,function(sym,e){stop();});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${About}","mouseover",function(sym,e){sym.stop("OVER");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${About}","mouseout",function(sym,e){sym.stop("UP");});
//Edge binding end
})("About_BTN");
//Edge symbol end:'About_BTN'

//=========================================================

//Edge symbol: 'Number_BTN'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",0,function(sym,e){stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",989,function(sym,e){stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",2000,function(sym,e){stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",3000,function(sym,e){stop();});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${Text2Copy2}","mouseover",function(sym,e){sym.stop("OVER");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${Text2Copy2}","mouseout",function(sym,e){sym.stop("UP");});
//Edge binding end
})("Number_BTN");
//Edge symbol end:'Number_BTN'

//=========================================================

//Edge symbol: 'Letters_BTN'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",0,function(sym,e){stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",989,function(sym,e){stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",2000,function(sym,e){stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",3000,function(sym,e){stop();});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${Text2Copy3}","mouseover",function(sym,e){sym.stop("OVER");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${Text2Copy3}","mouseout",function(sym,e){sym.stop("UP");});
//Edge binding end
})("Letters_BTN");
//Edge symbol end:'Letters_BTN'

//=========================================================

//Edge symbol: 'Style_BTN'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",0,function(sym,e){stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",989,function(sym,e){stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",2000,function(sym,e){stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",3000,function(sym,e){stop();});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${Text2Copy4}","mouseover",function(sym,e){sym.stop("OVER");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${Text2Copy4}","mouseout",function(sym,e){sym.stop("UP");});
//Edge binding end
})("Style_BTN");
//Edge symbol end:'Style_BTN'

//=========================================================

//Edge symbol: 'About_Content'
(function(symbolName){})("About_Content");
//Edge symbol end:'About_Content'
})})(AdobeEdge.$,AdobeEdge,"EDGE-179474352");